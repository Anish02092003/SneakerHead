
import React, { useContext } from 'react';
import { View, Text, Button, FlatList,ImageBackground,Image } from 'react-native';
import { useFavorites } from './FavoritesContext';
import styles from '../styles/styles';
const FavoritesScreen = ({navigation}) => {
  const { favorites, toggleFavorite} = useFavorites();
 const isEmptyFavorites = favorites.length ===0;
 const backPage =()=> {
   navigation.navigate('Product');
 }
//const keyExtractor = item?.toString();

  return (
    <View styles={styles.container}>
    <ImageBackground source={{ uri: 'https://static.vecteezy.com/system/resources/previews/036/375/664/original/seamless-pattern-cartoon-cute-dessert-character-cute-food-wallpaper-for-textile-gift-wrap-paper-vector.jpg'}} style={styles.imageBackground}>

    {isEmptyFavorites? (
      <View style={styles.page}>
        <Text style = {styles.title}>No favorites selected </Text>
      </View>
    ) : (
      <FlatList
        data={favorites}
    //keyExtractor={(item) =>item.id.toString()}
         keyExtractor={(item, index) =>index.toString()}
        renderItem={({item}) => (
        <View style={styles.card}>
      <Image source={{ uri: item.image }} style={styles.cardImage} />
      <Text style={styles.cardTitle}>{item.title}</Text>
      <Text>{item.description}</Text>
      <Text style={styles.cardPrice}>{item.price}</Text>
    
      <Button title="Remove from Favorites" onPress={() => toggleFavorite(item)} />
        </View>
        )}
        />
      )}
    
      <Button title="GoBack" onPress={backPage} />

      </ImageBackground>
    </View>
  );
};

export default FavoritesScreen;