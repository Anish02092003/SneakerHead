import React, { useState, useEffect, useContext, useMemo } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, ImageBackground, Button,ScrollView } from 'react-native';
import styles from '../styles/styles';
import { FavoritesContext, useFavorites } from './FavoritesContext';


const Product = ({ navigation, route }) => {
  const { username } = route.params || {};
  const { favorites, toggleFavorite} = useFavorites();

  const favoriteCount = useMemo(() => favorites.length,[favorites]);
  const handleFavorites = () =>{
    navigation.navigate('Favotiescreen');
  };
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 2000); // Simulate a loading time of 2 seconds
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  const previousPage = () => {
    navigation.navigate('Welcome');
  };

  
const item = [
  {
    id: '1',
    title: 'CheeseCkae',
    description: 'A classic creamy dessert with a graham cracker crust.',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQjydZjutjGggeqNOJaIbT27gxZNM4Cu4jR0g&s',
    price: '250',
  },
  {
    id: '2',
    title: 'Chocolate Lava Cake',
    description: 'Warm, gooey chocolate cake filled with molten chocolate.',
    image: 'https://preppykitchen.com/wp-content/uploads/2022/03/Chocolate-Lava-Cake-Recipe.jpg',
    price: '100',
  },
  {
    id: '3',
    title: 'Red velvet cakes',
    description: 'Italian dessert made with ladyfingers, mascarpone, and espresso.',
    image: 'https://www.julieseatsandtreats.com/wp-content/uploads/2019/11/Tiramisu-Recipe-2-of-2.jpg',
    price: '120',
  },
  {
    id: '4',
    title: 'Black Forest Pastry',
    description: '',
    image: 'https://www.ruchiskitchen.com/wp-content/uploads/2021/05/Eggless-Black-forest-Pastry-recipe-1-500x500.jpg',
    price: '100',
  },
  {
    id: '5',
    title: 'Blueberry Pastry',
    description: 'Warm, gooey chocolate cake filled with molten chocolate.',
    image: 'https://www.elloras.in/cdn/shop/products/Blueberry-Cheesecake_1.jpg?v=1659334029',
    price: '100',
  },
  {
    id: '6',
    title: 'Mango pastry',
    description: 'Italian dessert made with ladyfingers, mascarpone, and espresso.',
    image: 'https://www.shutterstock.com/image-photo/piece-mango-cake-isolated-white-260nw-1053048977.jpg',
    price: '120',
  },
];

  return (
    <View style={styles.page}>
      <ImageBackground source={{ uri: 'https://img.freepik.com/free-vector/watercolor-chocolate-pattern-design_23-2149671650.jpg' }}style={styles.imageBackground}>
        <Text style={styles.text}>Products for {username}</Text>
        <ScrollView Style={styles.container}>
            {item.map((item, index) => (
               <View key={item.id} style={styles.card}>
                  <Image source={{uri:item.image}} style={styles.cardImage} />
                  <Text style={styles.cardTitle}>{item.title}</Text>
                  <Text style={styles.cardPrice}>{item.price}</Text>
                 
                 <Button title='add to favorites' onPress={() => toggleFavorite(item)} />
                </View>
            ))}
            {item.length === 0 && (
                            <Text style={styles.title}>No results found</Text>
                        )}
          </ScrollView>
                          <Button title="GoBack" onPress={previousPage} /><View style={styles.buttonSpacing} /><Button
                              title="Go to Favorites"
                              onPress={() => navigation.navigate('FavoriteScreen')}
                              style={styles.buttonSpacing} />
      </ImageBackground>
    </View>
  );
  };

export default Product;